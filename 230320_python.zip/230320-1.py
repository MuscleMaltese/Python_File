s1=set([1,2,3]);  #set자료형 -> 순서가 없다, 따라서 인덱싱값 얻을 수 없다.
l1=list(s1);      #set자료형을 리스트로 변환 why? 요소에 접근하기 위해서
print(l1);
print(l1[0]);

s2=set([10,20,30,40,50]);
s3=set([10,20,300,400,500]);

#교집합(intersection) 구하기
print(s2&s3);
print(s2.intersection(s3));

#합집합(union) 구하기
print(s2|s3);
print(s2.union(s3));

#차집합(difference) 구하기
print(s2-s3);
print(s2.difference(s3));

#값 한개 추가하기 add
s2.add(1000);
print(s2);

#값 여러개 추가하기 update
s3.update([6,9]);
print(s3);

#특정 값 제거하기 remove
s3.remove(20);
print(s3);


#set자료형일때 사용 가능한 명령어 들!!