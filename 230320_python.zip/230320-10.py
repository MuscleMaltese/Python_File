#조건문
a=80;
if a>=90:
    print("학점은 A입니다.");
elif a>=80:
    print("학점은 B입니다.");
elif a>=70:
    print("학점은 C입니다.");
elif a>=60:
    print("학점은 D입니다.");
else:
    print("학점은 F입니다.");
