treeHit=0;
while treeHit<10:
    treeHit=treeHit+1;
    print("나무를 %d번 찍었다." %treeHit);
    # %d : 포매터(formatter) -> 정수형으로 출력해라 / 자바에서도 사용 가능
    
    if treeHit==10:
        print("나무가 넘어갔다.");
    break;