class Rect:
    count=0;  #클래스 변수
    #생성자
    def __init__(self,w,h): #아래바 좌우로 두개 쓰는 메서드를 스페셜 메서드(=매직 메서드) 라고 부른다.
        self.w=w;
        self.h=h;
        Rect.count+=1;
    #멤버 메서드
    def area(self):
        res=self.w*self.h;
        return res;

#Rect 클래스를 사용하여 객체(인스턴스) 생성
rect=Rect(10,5);
print(rect.area());
rect2=Rect(30,25);
print(rect2.area());