a=True;
b=False;
print(a);
print(b);
print(type(a));

c=[1,2,3,4];
#a변수의 값이 true이면 print문 실행, false이면 while문 빠져나감
while c:
    print(c.pop()); #요소 값 만큼 반복
    print(c);
if c:
    print("참");
else:
    print("거짓");
