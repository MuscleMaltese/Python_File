a=[1,2,3,4];
res=[num*3 for num in a]; #리스트 안에 반복문이 들어갔네..!!
print(res);

res2=[num*3 for num in a if num%2==0];
print(res2);