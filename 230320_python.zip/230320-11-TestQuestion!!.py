#함수 선언 키워드 : def / 함수명 : add / 매개변수 : a,b 
def add(a,b):
    return a+b;

def sub(a,b):
    return a-b;

def mul(a,b):
    return a*b;

def div(a,b):
    return a/b;

a=10; #위 함수에 (a,b)랑 같은 애들이 아님!!! (a,b)는 매개변수!!!!
b=20;
#함수 호출
print("%d과 %d을 더한 값은 %d입니다." %(a,b,add(10,20)));

# x=10;
# y=20;
# 함수 호출, x값은 add함수의 a변수로 받고, y값은 b변수로 받음
# c=add(x,y)
# #함수 호출
# print("%d와 %d를 더한 값은 %d 입니다" %a(x,y,c));

h=sub(a,b);
print("%d과 %d을 뺀 값은 %d입니다." %(a,b,h));

i=mul(a,b);
print("%d과 %d을 곱한 값은 %d입니다." %(a,b,i));

j=div(a,b);
print("%d과 %d을 나눈 값은 %d입니다." %(a,b,j)); #정수형이여서 0이 나온다

# j=div(a,b);
# print("%d과 %d을 나눈 값은 %.1f입니다." %(a,b,j)); #소숫점 출력하려면 %.1f이렇게 써주면 된다.

#---------------------------------------------------------------------------------------------

#키보드로 숫자를 입력받아서 변수에 저장하는 방법 input함수!!
#input으로 입력받은 요소는 문자열로 인식
k=input("숫자를 입력하세요 : ");
l=input("숫자를 입력하세요 : ");

#따라서 문자형 요소를 정수형으로 형변환!!
k=int(k);
l=int(l);

h=sub(k,l);
print("%d과 %d을 뺀 값은 %d입니다." %(k,l,h));

i=mul(k,l);
print("%d과 %d을 곱한 값은 %d입니다." %(k,l,i));

j=div(k,l);
print("%d과 %d을 나눈 값은 %.1f입니다." %(k,l,j));
