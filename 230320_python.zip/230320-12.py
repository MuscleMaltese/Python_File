#함수 선언 / 함수명 : add_mul / 매개변수 : choice, *args(길이가 정해져 있지 않다.)
def add_mul(choice, *args):  #*args는 매개변수 -> (*매개변수)는 입력하는대로 받아들이겠다!
     #만약 choice 변수값이 "add"라면
     if choice == "add": 
         #result변수 선언 및 초기화
         result = 0 
         #*args만큼 반복
         for i in args: #i는 10~60 / 6번 반복
             #result변수에 i값을 누적으로 더함
             result = result + i 
     #만약 choice변수 값이 "mul"이라면        
     elif choice == "mul": 
         #result변수 선언 및 초기화
         result = 1 
         #*args만큼 반복
         for i in args: 
             #result 변수에 i값을 누적으로 곱함
             result = result * i 
     #최종 연산된 result변수의 값을 호출한 곳으로 반환        
     return result 

#함수 호출
res=add_mul("add",10,20,30,40,50,60);
print(res);