class FourCal:
     def setdata(self, first, second):
         self.first = first
         self.second = second
     def add(self):
         result = self.first + self.second
         return result
     def mul(self):
         result = self.first * self.second
         return result
     def sub(self):
         result = self.first - self.second
         return result
     def div(self):
         result = self.first / self.second
         return result
     
#FourCal클래스를 사용하여 객체 a,b생성     
a=FourCal();
b=FourCal();
a.setdata(5,6);
b.setdata(3,8);

print(a.add());
print(b.sub());