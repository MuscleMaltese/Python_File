#함수명=lambda 매개변수1, 매개변수2, ..... 매개변수를 이용한 표현식!!
add=lambda a,b:a+b; #람다 매개변수1,매개변수2 : 람다로 뭐하고싶은지 쓰는곳

# def add(a,b):
#     return a+b; 얘랑 똑같다.

res=add(10,20);
print(res);