poket=["paper","money","cellphone"];
card=["kb","woork","sh"];
if "money"in poket:
    print("택시를 타고 가라");
else:
    if "card":
        print("택시를 타고 가라");  
    else:
        print("따릉이 타고 가라");
#중첩 if문 - else와 if를 붙여쓰지 않는다!