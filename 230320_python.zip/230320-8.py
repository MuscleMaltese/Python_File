#변수 i값이 2부터 9까지 반복
for i in range(2,10):
    #변수 j의 값이 1부터 9까지 반복
    for j in range(1,10): 
        #end=" " : 그 줄에 계속해서 출력 해 달라는 키워드
        print(i*j,end=" ");
    print('');