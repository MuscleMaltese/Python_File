class FourCal: #클래스 이름 대문자로 시작 / 뒤에 : 써야 함
    #pass #별다른 내용 없으면 pass라고 쓴다.(비어있는 클래스라는 뜻)
    n=0;
    m=0;
    def __init__(self,s,r): #__init__ -> 생성자(initializer) / 파이썬에서 클래스 만들때는 매개변수에 self키워드 써줘야 한다!!,self는 클래스 자체를 의미
        self.s=s; #클래스 안에서만 쓰는 멤버 변수
        self.r=r; #클래스 안에서만 쓰는 멤버 변수
        res=FourCal.n+FourCal.m; #FourCal얘네를 안쓰면 오류남..위에 있는 애들을 갖다 쓸땐 이렇게 써야 함!!
    #계산작업하는 일반 매서드
    def calc(self):
        res2=self.s*self.r;
        return res2;

#클래스 FourCal을 사용하여 a객체(인스턴스 변수)를 생성 / a는 인스턴스
a=FourCal(10,20);
print(a.calc());