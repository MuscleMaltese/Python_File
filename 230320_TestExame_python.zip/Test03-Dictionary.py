# 변수 a를 선언하고 딕셔너리 자료형 저장
a= {"이름":"조세호", "나이":38, "주소":"서울", "취미":"골프" };

# a딕셔너리에서 "이름" key에 해당하는 value출력
print(a["이름"]);

# a딕셔너리에 key:"키", value:175 요소 추가하고 출력
k="키";
a[k]=175;
print(a);

# a딕셔너리에서 key가 "취미"인 요소 삭제하고 출력
del a["취미"];
print(a);

# a딕셔너리에서 key만 가지고 리스트 만들어서 출력
print(a.keys());

for list in a.keys() :
    print(list);