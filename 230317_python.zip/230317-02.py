a=4.24E10; #실수
b=0x8ff;   #8진수
c=0xABC    #16진수 16진수는 8이 안들어감
d=10;
e=15;
f=d+e;
print(a);
print(b);
print(c);
print(f);
