a=5;
b=4;
print(a+b);
print(a-b);
print(a*b);
print(a/b);

#거듭제곱
c=2;
d=3;
print(c**d);


#나머지 반환
print(7%3);

#몫 반환(//)
print(8//2);

print("Life is too short, You need Python");
print("""Life is too short, You need Puppy""");
print('''Life is too short, You need cottencandy''');

#큰따옴표 안에 들어있는 작은 따옴표는 문자열을 나타내기 위한 기호로 인식되지 않는다.
print("Python's favorite food is perl");

#큰따옴표가 포함된 문자열이라면 작은따옴표로 둘러싸면 된다.
print("maru's favorite fruit is apple");

# ""나 ''를 문자열에 포함시키는 또 다른 방법 -> \백슬래시를 바로 앞에 적는다!!
print('maru\'s favorite fruit is apple');

print("I am\ngirl");
#읽기 불편 -> 작은따옴표 세개나 큰따옴표 세개로 해결
print("""집에 
가고
싶어요""");

#문자열 슬라이싱 첫번째 예제처럼 잘 안함..
c="오늘은 금요일 점심에 뭐먹지??";
print(c[0:6]); # : ~부터 ~까지
print(c[-5]); # : 뒤에서부터 5번째

res=c[0:6];
print(res);
#문자열은 배열처리 안해도 배열

#포매팅?? -> 형식을 지정해 주는것

