a=[1,2,3,4,5,6,7,8,9,10];
a.append(20); #append는 맨 뒤에 추가
print(a);

#정렬
b=[5,6,2,1,10,9,7,8,3];
b.append(20); 
b.sort();     #자바도 뒤에 .sort붙이면 정렬 바로 된다./오름차순 정렬
print(b);

c=[1,2,3,4,5,6,7,8,9,10];
c.append(20); #append는 맨 뒤에 추가
c.reverse();  #내림차순 정렬
print(c);
#숫자 6에 해당하는 인덱스 번호를 출력
print(c.index(5));
#숫자 20에 해당하는 인덱스 번호를 출력
print(c.index(20));

#a리스트의 중간에 데이터 삽입(insert)-0인덱스에 3데이터를 삽입
a.insert(0,3); #앞은 인덱스번호, 뒤는 집어넣을 데이터
print(a);
a.insert(7,100);
print(a);
a.insert(8,"만두");
print(a); #자료형에 상관 없군

#a리스트의 요소 제거
#remove는 지우고싶은거 괄호에 바로 쓴다.
a.remove(1); #리스트에서 괄호 안 요소 삭제
print(a);
a.remove(20);   
print(a);
a.remove("만두"); 
print(a);

#pop -> 뒤에꺼 지우기(처럼보이지만 끄집어 내는거임 그래서 a.pop()를 쓰면 끄집어내진것만 출력된다 )
a.pop();
print(a);
print(a.pop()); #리스트에서 제거된 원소를 반환
print(a);
a.pop(1); #리스트에서 인덱스 번호 1번 끄집어내기
print(a);

#리스트에 포함된 요소의 개수 세기
print(a.count(5));
a.append(5);
print(a.count(5));

#리스트 확장
a.extend([100,200]);
print(a);

