import os; 
a=10;
b=5.7;
c="A";
d='A';
e="오늘은 금요일";

print(a);
print(b);
print(c);
print(d);
print(e);