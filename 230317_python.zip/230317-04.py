str="나는 사과를 %d 개 먹었다." %3;
# num=3;
# str="나는 사과를"+num+"개 먹었다."; 이렇게 써도 되긴 함
print(str);

str2="나는 점심에 %s를 마셨다." %"단백질 쉐이크";
print(str2);

num=10;
day="삼일";
str3="나는 사과 %d개를 먹었다. %s 동안 먹었다." %(num,day);
print(str3);

str4="{0:<10}".format("안녕"); #왼쪽정렬
print(str4);
str5="{0:>10}".format("안녕"); #오른쪽 정렬
print(str5);
str6="{0:^10}".format("안녕"); #가운데 정렬
print(str6);

#소수점 n번째 자리까지만 출력하기
num=3.42134234;
print(num);
print(f'{num:0.2f}');
#앞의 f는 format, 뒤의 f는 float

num2=52.95643;
print(num2);
print(f'{num2:10.3f}'); #10자리 확보후, 소수점 3자리 까지 출력해라
                        #앞에 있는 0은 자리수를 표시하는 것
                        #-> 이게 뭘까..

                        