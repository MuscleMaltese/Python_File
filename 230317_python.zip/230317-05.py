#문자열 개수 세기
a='오늘은 날날날씨가 좋아요';

b=len(a);        #길이구함
print(b);

c=a.count(a);    #a변수의 특정 값의 개수 구하기
d=a.count('날')  #a변수의 '날'개수 새준다
print(c);
print(d);

e=a.find('좋아요');  #a변수의 값에서 특정 문자의 인덱스 번호 어디에 있는지 찾아준다
print(e);

f=a.find('사');  #a변수의 값에서 특정 문자의 인덱스 번호 어디에 있는지 찾아준다
print(f);        #값이 없으면 -1이 나온다.

g=a.index('좋아요');
print(g);

#어떤 글자의 위치를 찾기 위해서 index 혹은 find를 쓰면 된다.

#문자열 합치기(join) - 점프투 파이선 문자열 삽입이라고 되어있음
str=",".join('치킨돈가스우동');
print(str);

str2=",".join(['치킨','돈가스','우동']); #대괄호를 쓰면 단어나 특수 기호를 단어 사이에 넣을 수 있군
print(str2);

str3="Have a good time";
res3=str3.upper(); #upper : 대문자로 나옴
print(res3);

str4="HELP ME!!";  #lower : 소문자로 나옴
res4=str4.lower();
print(res4);

#공백 지우기
str5="                화이팅                ";
print(str5); 
print(str5.lstrip()); #왼쪽 공백 다 지워주세요
print(str5.rstrip()); #오른쪽 공백 다 지워주세요
print(str5.strip());  #양쪽 공백 다 지워주세요

#문자열 바꾸기(치환)
str6="주말에는 영화를 볼테야";
res5=str6.replace("영화","마루");
print(res5);

#문자열 나누기(자르기)
str7="일요일에 한강 가서 자전거 타자!!";
res6=str7.split(); #split괄호 안에 아무것도 안넣으면 공백을 기준으로 자른다.
print(res6);

str8="일요+일에한강가서+자전+거+타자!!";
res7=str8.split('+');
print(res7);

