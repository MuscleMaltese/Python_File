dic={1:'a',2:'b',3:'c'};
print(dic);
a='k'; #a는 k라고 선언
dic[a]='d'; #앞(a)가 key 뒤(d)가 vlaue -> 'k':'d'가 더해짐!!
print(dic);

#딕셔너리에서 요소 삭제
del dic[2];
print(dic);

#딕셔너리에서 키(key)를 사용하여 값(value)을 출력하기
print(dic['k']);